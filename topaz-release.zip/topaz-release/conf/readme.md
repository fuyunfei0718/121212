## ATTN:

* Before you start your server for the first time you need to copy the confs from the default directory **to this directory**.

* You can then set your database password and adjust the options as desired.

